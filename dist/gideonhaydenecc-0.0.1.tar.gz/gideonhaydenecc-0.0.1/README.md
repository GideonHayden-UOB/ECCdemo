ECC demo
